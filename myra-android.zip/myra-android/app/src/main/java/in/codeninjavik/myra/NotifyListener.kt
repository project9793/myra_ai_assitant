package in.codeninjavik.myra

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Reads notifications from social apps only (WhatsApp, Telegram, Instagram, Facebook).
 *
 * Android has no runtime permission for this: the person turns it on once in
 * Settings > Notifications > Device & app notifications > MYRA. Nothing is stored to disk,
 * the last 40 items live in memory and disappear when the process ends.
 */
class NotifyListener : NotificationListenerService() {

    data class Item(val app: String, val title: String, val text: String, val at: String)

    companion object {
        private val store = CopyOnWriteArrayList<Item>()
        private const val MAX = 40

        private val social = mapOf(
            "com.whatsapp" to "WhatsApp",
            "com.whatsapp.w4b" to "WhatsApp Business",
            "org.telegram.messenger" to "Telegram",
            "com.instagram.android" to "Instagram",
            "com.facebook.katana" to "Facebook",
            "com.facebook.orca" to "Messenger"
        )

        fun recent(): List<Item> = store.toList()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val s = sbn ?: return
        val app = social[s.packageName] ?: return
        if ((s.notification.flags and Notification.FLAG_ONGOING_EVENT) != 0) return

        val extras = s.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val body = (extras.getCharSequence(Notification.EXTRA_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString()?.trim().orEmpty()
        if (title.isEmpty() && body.isEmpty()) return

        val at = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.postTime))
        store.add(Item(app, title, body, at))
        while (store.size > MAX) store.removeAt(0)
    }
}
