package in.codeninjavik.myra

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * MYRA shell.
 *
 * The interface is the web app in assets/myra.html. This activity supplies what a web page cannot:
 * the phone's speech recognizer, the phone's text-to-speech, intents (dialer, SMS, opening apps,
 * sharing to social apps) and the runtime permissions those need.
 *
 * MYRA never places a call and never sends a message on its own: ACTION_DIAL, ACTION_SENDTO and
 * ACTION_SEND open the dialer / composer / share sheet pre-filled, and the person taps the final button.
 */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var sr: SpeechRecognizer? = null
    private var pending: (() -> Unit)? = null
    private var askedStartup = false

    private val reqMic = 1001
    private val reqContacts = 1002
    private val reqCamera = 1003
    private val reqStartup = 1004

    private val appAliases = mapOf(
        "whatsapp" to "com.whatsapp",
        "youtube" to "com.google.android.youtube",
        "camera" to "com.android.camera",
        "gallery" to "com.google.android.apps.photos",
        "photos" to "com.google.android.apps.photos",
        "settings" to "com.android.settings",
        "setting" to "com.android.settings",
        "chrome" to "com.android.chrome",
        "gmail" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana",
        "play store" to "com.android.vending",
        "telegram" to "org.telegram.messenger",
        "phone" to "com.android.dialer",
        "dialer" to "com.android.dialer",
        "messages" to "com.google.android.apps.messaging"
    )

    private val socialPackages = mapOf(
        "whatsapp" to "com.whatsapp",
        "telegram" to "org.telegram.messenger",
        "instagram" to "com.instagram.android",
        "facebook" to "com.facebook.katana"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        // the launcher showed SplashTheme; switch to the real theme before the first frame
        setTheme(R.style.AppTheme)
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        web = WebView(this)
        root.addView(
            web,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            // the page asks for the mic (voice mode) and the camera (Neural Lens)
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread { request.grant(request.resources) }
            }
        }
        web.addJavascriptInterface(Bridge(), "MyraNative")
        web.loadUrl("file:///android_asset/myra.html")

        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = Locale("hi", "IN")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = js("window.myraOnSpeakEnd && window.myraOnSpeakEnd()")
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = js("window.myraOnSpeakEnd && window.myraOnSpeakEnd()")
                    override fun onError(utteranceId: String?, errorCode: Int) =
                        js("window.myraOnSpeakEnd && window.myraOnSpeakEnd()")
                })
            }
        }

        // one-time onboarding: mic + camera together, so the first tap actually works
        web.postDelayed({ askStartupPermissions() }, 900)
    }

    private fun askStartupPermissions() {
        if (askedStartup) return
        askedStartup = true
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.RECORD_AUDIO)
        }
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            need.add(Manifest.permission.CAMERA)
        }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), reqStartup)
    }

    // ------------------------------------------------------------------ helpers

    private fun js(code: String) {
        runOnUiThread { web.evaluateJavascript(code, null) }
    }

    private fun say(text: String) {
        js("window.myraSay && window.myraSay(" + JSONObject.quote(text) + ")")
    }

    private fun hasDevanagari(text: String) = text.any { it.code in 0x0900..0x097F }

    private fun granted(permission: String) =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    private fun notificationAccessEnabled(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.contains(packageName)
    }

    private fun srMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Mic se awaaz nahi aa rahi."
        SpeechRecognizer.ERROR_CLIENT -> "Mic band ho gaya — dobara dabao."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic ki permission nahi mili — settings se allow karo."
        SpeechRecognizer.ERROR_NETWORK -> "Speech service tak internet nahi pahuncha."
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech service ka jawab nahi aaya."
        SpeechRecognizer.ERROR_NO_MATCH -> "Samajh nahi aaya — dobara bolo."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Mic abhi busy hai — ek second baad try karo."
        SpeechRecognizer.ERROR_SERVER -> "Speech server ne error diya."
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch suna nahi — dobara bolo."
        else -> "Mic mein dikkat aa gayi — dobara try karo."
    }

    // ------------------------------------------------------------------ speech in

    private fun startListening(lang: String) {
        runOnUiThread {
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                pending = { startListening(lang) }
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqMic)
                return@runOnUiThread
            }
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                js("window.myraOnSpeechError && window.myraOnSpeechError(" +
                    JSONObject.quote("Is phone par speech recognition nahi hai — Google app update karo, ya type karke bhejo.") + ")")
                return@runOnUiThread
            }

            sr?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            sr = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(eventType: Int, params: Bundle?) {}

                override fun onError(error: Int) {
                    js("window.myraOnSpeechError && window.myraOnSpeechError(" +
                        JSONObject.quote(srMessage(error)) + ")")
                }

                override fun onResults(results: Bundle?) {
                    val text = results
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: ""
                    js("window.myraOnSpeech && window.myraOnSpeech(" + JSONObject.quote(text) + ")")
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val t = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull() ?: return
                    js("window.myraOnSpeechPartial && window.myraOnSpeechPartial(" + JSONObject.quote(t) + ")")
                }
            })

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            }
            try {
                r.startListening(intent)
            } catch (e: Exception) {
                js("window.myraOnSpeechError && window.myraOnSpeechError(" +
                    JSONObject.quote("Mic start nahi ho paya.") + ")")
            }
        }
    }

    private fun stopListening() {
        runOnUiThread {
            try {
                sr?.stopListening()
                sr?.cancel()
            } catch (e: Exception) {
                // nothing to stop
            }
        }
    }

    // ------------------------------------------------------------------ phone actions

    private fun openDialer(number: String) {
        runOnUiThread {
            try {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)))
            } catch (e: Exception) {
                say("Dialer nahi khul paya.")
            }
        }
    }

    private fun findContactNumber(name: String): String? {
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use { c ->
            if (c.moveToFirst()) return c.getString(1)
        }
        return null
    }

    private fun dial(who: String) {
        val q = who.trim()
        val number = q.filter { it.isDigit() || it == '+' }
        if (number.length >= 3 && q.replace(Regex("[^0-9+]"), "").length == q.replace(" ", "").length) {
            openDialer(number)
            return
        }
        if (!granted(Manifest.permission.READ_CONTACTS)) {
            pending = { dial(q) }
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), reqContacts) }
            return
        }
        val found = try { findContactNumber(q) } catch (e: Exception) { null }
        if (found == null) say("'$q' naam ka contact nahi mila. Number bolo to dialer khol doon.")
        else openDialer(found)
    }

    private fun sms(who: String, body: String) {
        val q = who.trim()
        val number = q.filter { it.isDigit() || it == '+' }
        val target = if (number.length >= 3) number else {
            if (!granted(Manifest.permission.READ_CONTACTS)) {
                pending = { sms(q, body) }
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), reqContacts) }
                return
            }
            val found = try { findContactNumber(q) } catch (e: Exception) { null }
            if (found == null) {
                say("'$q' naam ka contact nahi mila.")
                return
            }
            found
        }
        runOnUiThread {
            try {
                val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(target))).apply {
                    if (body.isNotBlank()) putExtra("sms_body", body)
                }
                startActivity(intent)
            } catch (e: Exception) {
                say("Message app nahi khul paya.")
            }
        }
    }

    private fun openApp(name: String) {
        val q = name.trim().lowercase()
        val pm = packageManager

        val alias = appAliases[q] ?: appAliases.entries.firstOrNull { q.contains(it.key) }?.value
        if (alias != null) {
            val launch = pm.getLaunchIntentForPackage(alias)
            if (launch != null) {
                runOnUiThread { try { startActivity(launch) } catch (e: Exception) { say("$name nahi khul paya.") } }
                return
            }
        }

        val probe = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(probe, 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
        if (hit == null) {
            say("'$name' naam ka koi app is phone par nahi mila.")
            return
        }
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        runOnUiThread {
            try {
                if (launch != null) startActivity(launch) else say("$name nahi khul paya.")
            } catch (e: Exception) {
                say("$name nahi khul paya.")
            }
        }
    }

    /**
     * Shares text to a social app. This is the only supported way to "post" for the user: the app's
     * own share sheet opens with the text filled in and the person sends it. No app can type into
     * WhatsApp or Instagram for you without accessibility access.
     */
    private fun shareText(target: String, text: String) {
        val key = target.trim().lowercase()
        val pkg = socialPackages[key] ?: appAliases[key]
        runOnUiThread {
            try {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                    if (pkg != null) setPackage(pkg)
                }
                if (pkg != null) {
                    startActivity(intent)
                } else {
                    startActivity(Intent.createChooser(intent, "Kis app par bheju?"))
                }
            } catch (e: Exception) {
                say("'$target' par share nahi kar payi — app install hai?")
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val allGranted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        val action = pending
        pending = null

        if (requestCode == reqStartup) {
            // tell the page so its Permissions list refreshes
            js("window.myraOnPermissionsChanged && window.myraOnPermissionsChanged()")
            return
        }
        if (allGranted && action != null) {
            action()
        } else if (!allGranted) {
            val what = when (requestCode) {
                reqMic -> "Mic"
                reqCamera -> "Camera"
                reqContacts -> "Contacts"
                else -> "Permission"
            }
            say("$what ki permission nahi mili — phone settings se allow karo.")
        }
        js("window.myraOnPermissionsChanged && window.myraOnPermissionsChanged()")
    }

    override fun onDestroy() {
        try {
            sr?.destroy()
        } catch (e: Exception) {
            // already gone
        }
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (this::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    // ------------------------------------------------------------------ bridge

    /** Every method here runs on a JavaScript thread, so UI work is posted to the main thread. */
    inner class Bridge {

        @JavascriptInterface
        fun available(): Boolean = true

        // ---- voice
        @JavascriptInterface
        fun speak(text: String, rate: Float) {
            if (!ttsReady) {
                js("window.myraOnSpeakEnd && window.myraOnSpeakEnd()")
                return
            }
            runOnUiThread {
                try {
                    tts?.setSpeechRate(if (rate > 0.1f) rate else 1f)
                    tts?.language = if (hasDevanagari(text)) Locale("hi", "IN") else Locale("en", "IN")
                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myra-" + System.currentTimeMillis())
                } catch (e: Exception) {
                    js("window.myraOnSpeakEnd && window.myraOnSpeakEnd()")
                }
            }
        }

        @JavascriptInterface
        fun stopSpeak() {
            runOnUiThread {
                try { tts?.stop() } catch (e: Exception) { /* noop */ }
                js("window.myraOnSpeakEnd && window.myraOnSpeakEnd()")
            }
        }

        @JavascriptInterface
        fun listen(lang: String) = this@MainActivity.startListening(if (lang.isBlank()) "hi-IN" else lang)

        @JavascriptInterface
        fun stopListen() = this@MainActivity.stopListening()

        // ---- permissions
        @JavascriptInterface
        fun permissions(): String {
            val o = JSONObject()
            o.put("mic", granted(Manifest.permission.RECORD_AUDIO))
            o.put("camera", granted(Manifest.permission.CAMERA))
            o.put("contacts", granted(Manifest.permission.READ_CONTACTS))
            o.put("notifications", notificationAccessEnabled())
            o.put("native", true)
            return o.toString()
        }

        @JavascriptInterface
        fun requestPermission(name: String) {
            val n = name.trim().lowercase()
            runOnUiThread {
                when (n) {
                    "mic", "microphone" -> {
                        if (granted(Manifest.permission.RECORD_AUDIO)) {
                            js("window.myraOnPermissionsChanged && window.myraOnPermissionsChanged()")
                        } else {
                            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), reqMic)
                        }
                    }
                    "camera" -> {
                        if (granted(Manifest.permission.CAMERA)) {
                            js("window.myraOnPermissionsChanged && window.myraOnPermissionsChanged()")
                        } else {
                            requestPermissions(arrayOf(Manifest.permission.CAMERA), reqCamera)
                        }
                    }
                    "contacts" -> {
                        if (granted(Manifest.permission.READ_CONTACTS)) {
                            js("window.myraOnPermissionsChanged && window.myraOnPermissionsChanged()")
                        } else {
                            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), reqContacts)
                        }
                    }
                    "notifications", "social" -> openNotificationAccess()
                    else -> toast("Aisi permission nahi hai: $name")
                }
            }
        }

        /** Notification access is a special access screen; Android has no runtime dialog for it. */
        @JavascriptInterface
        fun openNotificationAccess() {
            runOnUiThread {
                try {
                    startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
                } catch (e: Exception) {
                    try {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                    } catch (e2: Exception) {
                        say("Settings nahi khul paye.")
                    }
                }
            }
        }

        /** Last notifications from social apps, newest first. Empty unless notification access is on. */
        @JavascriptInterface
        fun notifications(): String {
            val arr = JSONArray()
            if (!notificationAccessEnabled()) return arr.toString()
            val items = NotifyListener.recent()
            for (i in items.indices.reversed()) {
                val it = items[i]
                val o = JSONObject()
                o.put("app", it.app)
                o.put("title", it.title)
                o.put("text", it.text)
                o.put("at", it.at)
                arr.put(o)
            }
            return arr.toString()
        }

        // ---- phone commands
        @JavascriptInterface
        fun dial(who: String) = this@MainActivity.dial(who)

        @JavascriptInterface
        fun sms(who: String, text: String) = this@MainActivity.sms(who, text)

        @JavascriptInterface
        fun openApp(name: String) = this@MainActivity.openApp(name)

        @JavascriptInterface
        fun share(target: String, text: String) = this@MainActivity.shareText(target, text)

        @JavascriptInterface
        fun toast(message: String) {
            runOnUiThread { Toast.makeText(this@MainActivity, message, Toast.LENGTH_SHORT).show() }
        }
    }
}
