# The JS bridge is reached by name from JavaScript, so keep its members.
-keepclassmembers class in.codeninjavik.myra.MainActivity$Bridge {
    public *;
}

# The system instantiates the notification listener by class name.
-keep class in.codeninjavik.myra.NotifyListener { *; }
