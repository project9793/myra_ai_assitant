# MYRA — Android shell (WebView + native bridge)

Ye ek chhota Android project hai jo pehle banayi hui web app (`myra-voice-assistant.html`) ko
APK ke andar chalata hai — **plus** wo teen cheezein jodta hai jo browser nahi kar sakta:
phone ka speech recognizer, phone ka text-to-speech, aur intents (dialer, SMS, app kholna).

WebView wrapper (jaise web-to-APK tools banate hain) mein mic aur TTS kaam nahi karte, isliye
yahan bridge hai. Interface wahi HTML hai — design, Gemini integration, settings, sab same.

## Kya kaam karta hai

| Cheez | Kaise |
| --- | --- |
| Bolna (mic) | Android ka `SpeechRecognizer` — Hindi + English, partial results |
| Jawab bol kar sunana | Android ka `TextToSpeech`, Devanagari ho to hi-IN voice |
| "Ramesh ko call karo" | Contacts mein naam dhoondh ke **dialer khol deta hai** (call tum dabate ho) |
| "98765 43210 ko call karo" | Number ke saath dialer |
| "Ramesh ko message bhejo" | SMS composer khulta hai, number bhara hua |
| "WhatsApp kholo" / "camera kholo" | App launch (common apps ka alias map + label search) |
| Baaki sab sawaal | Gemini (key app ke Setup panel mein daalte ho) |

MYRA khud call nahi lagati aur SMS khud nahi bhejti — `ACTION_DIAL` aur `ACTION_SENDTO` sirf
dialer/composer kholte hain, aakhri button tum dabate ho. Ye jaan-boojh kar aisa rakha hai:
galat number par call jaana ya galat message jaana reversible nahi hota.

## Jo abhi nahi hai

- Screen reading / doosre apps mein tap karna (WhatsApp ke andar reply type karna) — uske liye
  `AccessibilityService` chahiye, wo is shell mein nahi hai. Bolo to alag se jod denge.
- Background mein 24x7 sunna — app band hone par mic band ho jaata hai.
- Wake word ("Hey MYRA") — uske liye hamesha chalne wala foreground service chahiye.

## APK kaise banao

1. [Android Studio](https://developer.android.com/studio) install karo (Ladybug ya naya).
2. **Open** → is folder ko (`myra-android`) select karo → Gradle sync hone do.
   Pehli baar Gradle wrapper khud ban jaata hai; internet chahiye.
3. Phone ko USB se jodo (USB debugging on) ya emulator chalao.
4. **Run ▶** dabao — app install ho jaayega.
5. Release APK: **Build → Generate Signed Bundle / APK → APK**, apni keystore banao.

Command line se (JDK 17 + Android SDK installed ho to):

```bash
cd myra-android
./gradlew assembleDebug        # app/build/outputs/apk/debug/app-debug.apk
```

## Pehli baar app kholne par

1. Mic permission maangega — Allow karo.
2. Setup panel mein Gemini API key daalo (`aistudio.google.com/apikey`) → Save.
3. "MYRA, tum kaun ho?" bol ke test karo.
4. Call/app commands test karte waqt pehli baar contacts permission maangega.

## Structure

```
myra-android/
  app/src/main/
    assets/myra.html                 # wahi web app + native bridge hooks
    java/in/codeninjavik/myra/MainActivity.kt
    AndroidManifest.xml              # RECORD_AUDIO, READ_CONTACTS, INTERNET, <queries>
    res/values/styles.xml
  app/build.gradle.kts
  settings.gradle.kts
  build.gradle.kts
```

Koi third-party library nahi hai — sirf Android framework + jo WebView phone mein pehle se hai.

## Bridge API (JS se)

```js
window.MyraNative.speak(text, rate)   // TTS, band hone par window.myraOnSpeakEnd()
window.MyraNative.stopSpeak()
window.MyraNative.listen("hi-IN")     // result: window.myraOnSpeech(text)
window.MyraNative.stopListen()
window.MyraNative.dial("naam ya number")
window.MyraNative.sms("naam ya number", "text")
window.MyraNative.openApp("whatsapp")
window.MyraNative.toast("message")
```

## Dhyaan dene wali baatein

- **API key APK mein na daalo.** App mein key user khud panel se daalta hai aur wo WebView ke
  localStorage mein rehti hai. Agar key code mein hardcode karoge to APK se nikalna aasaan hai.
- Ye WebView shell hai: agar future mein native UI chahiye (Compose), tab UI dobara likhna padega.
- `targetSdk 34`, `minSdk 24` (Android 7.0+).
- Play Store par daalne se pehle privacy policy chahiye hogi, kyunki app mic aur contacts use karti hai.
